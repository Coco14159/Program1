﻿//Program 1
//Grading ID: S2303
//CIS 199-01
//28SEP23
//This program takes user input and calculates a quick price quote using very straightfoard variable naming, calculations, and an if/else statement. 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program1NewUpload
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //this is the opening line if code to the user, no input is needed
            Console.WriteLine("Hello! Welcome to HHM's Legal Services!");

            //this section starts the user input-driven section and starts declaring variables

            Console.WriteLine("Please enter your name, or your client's name:"); // Client Name
            string clientName = Console.ReadLine();

            Console.WriteLine("Please enter your case type; Criminal or Civil:"); // Case Type
            string caseType = Console.ReadLine();

            Console.WriteLine("Please enter a brief case description:"); // Case Description
            string caseDescription = Console.ReadLine();

            Console.WriteLine("We offer a standard hourly rate for all our attorneys. Please enter how many hours you may need for an attorney (aprox):"); // Attorney Hours
            double attorneyHours = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Paralegal services are offered as well. Please enter how many days you might need paralegal assistance:"); // Paralegal Days
            double paralegalDays = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("We offer printing services! If you would like us to print anything for you, provide how much paper you will need printed, otherwise please enter 0:"); // Paper Printer
            int printPaper = int.Parse(Console.ReadLine());

            Console.WriteLine("These are our standard services, however we do offer further research for a flat rate of $750. Would you like Research Services? 1 for yes, 0 for no."); // Research Fee
            int researchServices = int.Parse(Console.ReadLine());


            //Here we will implement our calculataions 

            const double attorneyRate = 250;
            const double pagePrice = 0.10;
            const double paralegalRate = 300;

            double attorneyCost = attorneyHours * attorneyRate;
            double paralegalCost = paralegalDays * paralegalRate;
            double printCost = printPaper * pagePrice;
            double reams = (printPaper * 1.1) / 500;
            double researchFee = 0.0;
            double totalCost = attorneyCost + paralegalCost + printCost + researchFee;

            //This is the if statement for the user input from the research service question
            if (researchServices == 1)
            {
                researchFee = 750;
            }
            else
            {
                researchFee = 0;
            }


            //Here we start assigning variables with inputs the user has given us

            Console.WriteLine("Client name:" + clientName);
            Console.WriteLine("Case type:" + caseType);
            Console.WriteLine("Case Description" + caseDescription);
            Console.WriteLine("Ream amount needed" + reams);
            Console.WriteLine("Cost of attorney: $" + attorneyCost);
            Console.WriteLine("Cost of paralegal: $" + paralegalCost);
            Console.WriteLine("Printing cost: $" + printCost);
            Console.WriteLine("Total cost of services: $" + totalCost);
        }
    }
}
